<?php

namespace Database\Seeders;

use Illuminate\Database\Seeder;

class YoutubeMediaSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        //
    }
}
